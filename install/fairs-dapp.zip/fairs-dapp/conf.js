(function () {
  window.BLOCKCHAIN_ADDR = "https://www.mos.ru/bchback/";
  window.FACTORY_ADDR = "0x72b137e993c22f0a57467cecee6890a1c9603e87";
  window.ELASTIC_ADDR = "https://www.mos.ru/bchelastic";
  window.USE_ELASTIC = true;
})();